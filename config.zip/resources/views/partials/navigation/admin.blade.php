<li><a class="nav-link" href="#">{{ __("Administrar Empresas") }}</a></li>
<li><a class="nav-link" href="#">{{ __("Administrar Usuarios") }}</a></li>
<li><a class="nav-link" href="#">{{ __("Administrar Clientes") }}</a></li>
@include('partials.navigations.logged')