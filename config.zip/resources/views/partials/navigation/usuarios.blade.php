
@include ('partials.navigations.comunes')
<li><a class="nav-link" href="#">{{ __("Cursos desarrollados por mi") }}</a></li>
<li><a class="nav-link" href="#">{{ __("Crear curso") }}</a></li>


@include('partials.navigations.logged')