<li><a class="nav-link" href="#">{{ __("Mi perfil") }}</a></li>
<li><a class="nav-link" href="#">{{ __("Mis empresas") }}</a></li>