<?php $__env->startSection('title','Suma Apoyo Empresarial- Contacto '); ?>

<?php $__env->startSection('contacto','active'); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTACTO SECTION -->
    <section id="contacto-section">
        <div class="container">
            <div class="row mx-2 mt-5">
                <div id="contacto-datos" class="col-md-6 offset-md-3 p-3">
                    <h3 class="display-7 text-muted"><?php echo e(__("Visítanos en nuestras oficinas de")); ?></h3>
                    <p class="display-7 text-primary"><i class="fas fa-map-marker-alt"></i> C/Sant Marian 57, 1º-2ª, Terrassa </p>
                    <p class="display-7 text-muted"><?php echo e(__("o envíanos un mail a...")); ?></p>
                    <a href="mailto:info@sumaempresa.com" class="display-7"><i class="fas fa-at fa-lg"></i> info@sumaempresa.com</a>
                    <p class="small text-muted pt-1 px-4"><?php echo e(__("Inscrita")); ?></p>
                </div>
            </div>
        </div>
    </section>
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('layouts.layoutsuma', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>