<?php $__env->startSection('title','Suma Apoyo - Equipo '); ?>
<?php $__env->startSection('equipo','active'); ?>

<?php if(App::getLocale()=='es'): ?>
    <?php $__env->startSection('title','Suma - Equipo'); ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('partials.suma.es.equipoEs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldSection(); ?>
<?php else: ?>
    <?php $__env->startSection('title','Suma - Team'); ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('partials.suma.en.equipoEn', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.layoutsuma', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>