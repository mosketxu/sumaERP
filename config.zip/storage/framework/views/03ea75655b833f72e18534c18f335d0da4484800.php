<?php $__env->startSection('title','Suma Apoyo - Equipo '); ?>
<?php $__env->startSection('equipo','active'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(App::getLocale()=='es'): ?>
        <?php echo $__env->make('suma.equipoEs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('suma.equipoEn', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('layouts.layoutsuma', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>