<?php $__env->startSection('menuservicios'); ?>
    <li class="nav-item dropdown" >
        <a href="#" class="nav-link text-primary dropdown-toggle" data-toggle="dropdown"><?php echo e(__("Servicios")); ?></a>
        <div class="dropdown-menu">
            <a href="<?php echo e(route( 'home', '#queofrecemos-head-section')); ?>" class="dropdown-item"><?php echo e(__("Qué ofrecemos")); ?></a>
            <a href="<?php echo e(route( 'home', '#financiera-head-section')); ?>" class="dropdown-item"><?php echo e(__("Área Financiera")); ?></a>
            <a href="<?php echo e(route( 'suma', '#contable-head-section')); ?>" class="dropdown-item"><?php echo e(__("Área Contable")); ?></a>
            <a href="<?php echo e(route( 'suma', '#fiscal-head-section')); ?>" class="dropdown-item"><?php echo e(__("Área Fiscal")); ?></a>
            <a href="<?php echo e(route( 'suma', '#mercantil-head-section')); ?> " class=" dropdown-item "><?php echo e(__("Área Mercantil")); ?></a>
            <a href="<?php echo e(route( 'suma', '#administracion-head-section')); ?> " class="dropdown-item "><?php echo e(__("Administración")); ?></a>
            <a href="<?php echo e(route( 'suma', '#consultoria-head-section')); ?> " class="dropdown-item "><?php echo e(__("Consultoría - RRHH")); ?></a>
            <a href="<?php echo e(route( 'suma', 'politica')); ?> " class="dropdown-item "><?php echo e(__("Politica de seguridad")); ?></a>
        </div>
    </li>
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('home','active'); ?>

<?php $__env->startSection('carrusel'); ?>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item carousel-image-1 active">
            </div>

            <div class="carousel-item carousel-image-2">
                <div class="container d-flex">
                    <div class="carousel-caption text-left mb-3">
                        <h3 class="display-3"><span class="textoFondoTitulo"><?php echo e(__("Contabilidad")); ?></span></h3>
                        <p class="lead d-none d-md-block"><span class="textoFondo"><?php echo e(__("Mantenemos una imagen fiel y veraz del estado de tu negocio.")); ?></span></p>
                    </div>
                </div>
            </div>

            <div class="carousel-item carousel-image-3">
                <div class="container">
                    <div class="carousel-caption text-right mb-3">
                        <h3 class="display-3"><span class="textoFondoTitulo"><?php echo e(__("Fiscalidad")); ?></span></h3>
                        <p class="lead d-none d-md-block"><span class="textoFondo"><?php echo e(__("Te asesoramos en los aspectos legales.")); ?></span></p>
                    </div>
                </div>
            </div>
            <div class="carousel-item carousel-image-4">
                <div class="container">
                    <div class="carousel-caption-2 text-left mt-3">
                        <h3 class="display-3"><span class="textoFondoTitulo"><?php echo e(__("Administración")); ?></span></h3>
                        <p class="lead d-none d-md-block"><span class="textoFondo"><?php echo e(__("Te ayudamos con tus tareas diarias para que te centres en tus objetivos.")); ?></span></p>
                    </div>
                </div>
            </div>
            <div class="carousel-item carousel-image-5">
                <div class="container">
                    <div class="carousel-caption-2 text-left mt-3">
                        <h3 class="display-3"><span class="textoFondoTitulo"><?php echo e(__("Consultoria")); ?></span></h3>
                        <p class="lead d-none d-md-block"><span class="textoFondo"><?php echo e(__("Analizamos tus procesos en busca de la mejora.")); ?></span></p>
                    </div>
                </div>
            </div>
        </div>

        <a href="#myCarousel" data-slide="prev" class="carousel-control-prev flechita">
                <span class="carousel-control-prev-icon text-primary"></span>
        </a>

        <a href="#myCarousel" data-slide="next" class="carousel-control-next flechita">
                <span class="carousel-control-next-icon"></span>
        </a>
    </div>
<?php echo $__env->yieldSection(); ?>

<?php if(App::getLocale()=='es'): ?>
    <?php $__env->startSection('title','Suma - Bienvenido'); ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('partials.suma.es.ppalEs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldSection(); ?>
<?php else: ?>
    <?php $__env->startSection('title','Suma - Welcome'); ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('partials.suma.en.ppalEn', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.layoutsuma', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>