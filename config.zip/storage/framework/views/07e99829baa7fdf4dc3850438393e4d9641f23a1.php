    
<?php $__env->startSection('piefijo','fixed-bottom mt-5 mb-3'); ?>
<?php $__env->startSection('politica','active'); ?>
<?php $__env->startSection('carrusel'); ?>
    <div class="container">
        <div class="col-md-12 mt-5 ">
            <div id="imgTop" class="" >
                <img src="img/LOGO_SUMA_1200x400.jpg" class="img-responsive carousel" alt="Suma Apoyo Empresarial S.L.">
            </div>
        </div>
    </div>
<?php echo $__env->yieldSection(); ?>

<?php if(App::getLocale()=='es'): ?>
    <?php $__env->startSection('title','Suma - Politica Seguridad'); ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('suma.es.politicaEs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldSection(); ?>
<?php else: ?>
    <?php $__env->startSection('title','Suma - Private Policy'); ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('suma.en.politicaEn', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.layoutsuma', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>