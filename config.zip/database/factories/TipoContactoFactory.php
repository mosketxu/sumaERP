<?php

use Faker\Generator as Faker;

$factory->define(App\TipoContacto::class, function (Faker $faker) {
    return [
        //
    ];
});
