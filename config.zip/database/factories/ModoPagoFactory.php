<?php

use Faker\Generator as Faker;

$factory->define(App\ModoPago::class, function (Faker $faker) {
    return [
        //
    ];
});
