<?php

use Faker\Generator as Faker;

$factory->define(App\PeriodoPago::class, function (Faker $faker) {
    return [
        //
    ];
});
